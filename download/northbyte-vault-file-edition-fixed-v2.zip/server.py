from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time
import uuid
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
USERS_FILE = DATA / "users.json"
VAULT_DIR = DATA / "vaults"
SESSION_TTL = 12 * 60 * 60
PBKDF2_ITERATIONS = 600_000
SCRYPT_N = 2**15
S = 8
P = 1

DATA.mkdir(exist_ok=True)
VAULT_DIR.mkdir(exist_ok=True)
LOCK = threading.RLock()
SESSIONS: dict[str, dict] = {}
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def load_users():
    with LOCK:
        if not USERS_FILE.exists():
            return {"version": 1, "users": {}}
        try:
            data = json.loads(USERS_FILE.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or not isinstance(data.get("users"), dict):
                raise ValueError("Invalid users file")
            return data
        except Exception:
            # Fail closed instead of silently replacing a possibly important file.
            raise RuntimeError("data/users.json is invalid or corrupted")


def save_users(data):
    tmp = USERS_FILE.with_suffix(".json.tmp")
    raw = json.dumps(data, indent=2, ensure_ascii=False)
    tmp.write_text(raw, encoding="utf-8")
    os.replace(tmp, USERS_FILE)
    try:
        os.chmod(USERS_FILE, 0o600)
    except OSError:
        pass


def normalize_email(v: str) -> str:
    return v.strip().casefold()


def valid_email(v: str) -> bool:
    return len(v) <= 254 and bool(EMAIL_RE.match(v))


def safe_id():
    return uuid.uuid4().hex


def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def scrypt_hash(verifier_b64: str, salt_b64: str) -> str:
    verifier = base64.b64decode(verifier_b64)
    salt = base64.b64decode(salt_b64)
    out = hashlib.scrypt(verifier, salt=salt, n=SCRYPT_N, r=S, p=P, dklen=32, maxmem=64 * 1024 * 1024)
    return base64.b64encode(out).decode()


def new_auth_salt():
    return base64.b64encode(secrets.token_bytes(16)).decode()


def sanitize_vault_blob(blob):
    if not isinstance(blob, dict):
        raise ValueError("vault must be an object")
    allowed = {"format", "version", "kdf", "iterations", "salt", "iv", "ciphertext"}
    if set(blob) - allowed:
        raise ValueError("unknown vault fields")
    if blob.get("format") != "NBV1": raise ValueError("invalid vault format")
    if blob.get("version") != 1: raise ValueError("invalid vault version")
    if not all(isinstance(blob.get(x), str) for x in ("salt", "iv", "ciphertext")):
        raise ValueError("invalid vault encoding")
    if not (20 <= len(blob["ciphertext"]) <= 20_000_000):
        raise ValueError("vault is empty or too large")
    return blob


def cookie_token(headers):
    raw = headers.get("Cookie", "")
    for part in raw.split(";"):
        part = part.strip()
        if part.startswith("NBV_SESSION="):
            return part.split("=", 1)[1]
    return None


def user_for_request(handler):
    token = cookie_token(handler.headers)
    if not token:
        return None, None
    with LOCK:
        record = SESSIONS.get(token)
        if not record:
            return None, None
        if time.time() > record["expires"]:
            SESSIONS.pop(token, None)
            return None, None
        record["expires"] = time.time() + SESSION_TTL
        return record["email"], token


class Handler(BaseHTTPRequestHandler):
    server_version = "NorthByteVault/1.0"

    def log_message(self, *_args):
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        super().end_headers()

    def json_response(self, payload, status=HTTPStatus.OK, extra_headers=None):
        raw = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        if extra_headers:
            for k, v in extra_headers:
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(raw)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0 or length > 20_500_000:
            raise ValueError("invalid request size")
        raw = self.rfile.read(length)
        data = json.loads(raw.decode("utf-8"))
        if not isinstance(data, dict):
            raise ValueError("object required")
        return data

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/health":
            return self.json_response({"status": "ok", "storage": "users.json + encrypted .nbv"})
        if parsed.path == "/api/account-info":
            email = normalize_email(parse_qs(parsed.query).get("email", [""])[0])
            if not valid_email(email):
                return self.json_response({"error": "invalid-email"}, HTTPStatus.BAD_REQUEST)
            user = load_users()["users"].get(email)
            if not user:
                return self.json_response({"error": "not-found"}, HTTPStatus.NOT_FOUND)
            return self.json_response({"email": email, "authSalt": user["authSalt"]})
        if parsed.path == "/api/me":
            email, _token = user_for_request(self)
            if not email:
                return self.json_response({"authenticated": False})
            return self.json_response({"authenticated": True, "email": email})
        if parsed.path == "/api/vault":
            email, _token = user_for_request(self)
            if not email:
                return self.json_response({"error": "unauthorized"}, HTTPStatus.UNAUTHORIZED)
            users = load_users()["users"]
            user = users[email]
            blob = json.loads((VAULT_DIR / user["vaultFile"]).read_text(encoding="utf-8"))
            return self.json_response(blob)
        # Serve files.
        if parsed.path == "/":
            path = ROOT / "index.html"
        else:
            rel = parsed.path.lstrip("/")
            path = (ROOT / rel).resolve()
            if ROOT not in path.parents and path != ROOT:
                self.send_error(HTTPStatus.NOT_FOUND); return
        if not path.is_file():
            self.send_error(HTTPStatus.NOT_FOUND); return
        data = path.read_bytes()
        ctype = "text/plain; charset=utf-8"
        if path.suffix == ".html": ctype = "text/html; charset=utf-8"
        elif path.suffix == ".css": ctype = "text/css; charset=utf-8"
        elif path.suffix == ".js": ctype = "text/javascript; charset=utf-8"
        elif path.suffix == ".png": ctype = "image/png"
        elif path.suffix == ".svg": ctype = "image/svg+xml"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers(); self.wfile.write(data)

    def do_POST(self):
        parsed = urlparse(self.path)
        try:
            body = self.read_json()
        except Exception as exc:
            return self.json_response({"error": str(exc)}, HTTPStatus.BAD_REQUEST)

        if parsed.path == "/api/register":
            email = normalize_email(str(body.get("email", "")))
            auth_salt = str(body.get("authSalt", ""))
            verifier = str(body.get("verifier", ""))
            vault = body.get("vault")
            if not valid_email(email): return self.json_response({"error":"invalid-email"}, HTTPStatus.BAD_REQUEST)
            if len(verifier) < 40: return self.json_response({"error":"invalid-verifier"}, HTTPStatus.BAD_REQUEST)
            if not auth_salt: return self.json_response({"error":"invalid-salt"}, HTTPStatus.BAD_REQUEST)
            try: vault = sanitize_vault_blob(vault)
            except Exception as exc: return self.json_response({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
            with LOCK:
                data = load_users()
                if email in data["users"]:
                    return self.json_response({"error":"exists"}, HTTPStatus.CONFLICT)
                user_id = safe_id()
                vault_file = f"{user_id}.nbv"
                verifier_hash = scrypt_hash(verifier, auth_salt)
                data["users"][email] = {
                    "id": user_id,
                    "email": email,
                    "authSalt": auth_salt,
                    "verifierHash": verifier_hash,
                    "vaultFile": vault_file,
                    "createdAt": now_iso(),
                }
                tmp = VAULT_DIR / (vault_file + ".tmp")
                tmp.write_text(json.dumps(vault, ensure_ascii=False), encoding="utf-8")
                os.replace(tmp, VAULT_DIR / vault_file)
                try: os.chmod(VAULT_DIR / vault_file, 0o600)
                except OSError: pass
                save_users(data)
            return self._login(email)

        if parsed.path == "/api/login":
            email = normalize_email(str(body.get("email", "")))
            verifier = str(body.get("verifier", ""))
            if not valid_email(email): return self.json_response({"error":"invalid-email"}, HTTPStatus.BAD_REQUEST)
            user = load_users()["users"].get(email)
            if not user:
                return self.json_response({"error":"invalid-credentials"}, HTTPStatus.UNAUTHORIZED)
            try:
                supplied = scrypt_hash(verifier, user["authSalt"])
            except Exception:
                return self.json_response({"error":"invalid-credentials"}, HTTPStatus.UNAUTHORIZED)
            if not hmac.compare_digest(supplied, user["verifierHash"]):
                return self.json_response({"error":"invalid-credentials"}, HTTPStatus.UNAUTHORIZED)
            return self._login(email)

        if parsed.path == "/api/logout":
            token = cookie_token(self.headers)
            if token:
                with LOCK: SESSIONS.pop(token, None)
            return self.json_response({"ok": True}, extra_headers=[("Set-Cookie", "NBV_SESSION=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax")])

        self.send_error(HTTPStatus.NOT_FOUND)

    def _login(self, email):
        token = secrets.token_urlsafe(32)
        with LOCK:
            SESSIONS[token] = {"email": email, "expires": time.time() + SESSION_TTL}
        return self.json_response(
            {"ok": True, "email": email},
            extra_headers=[("Set-Cookie", f"NBV_SESSION={token}; Max-Age={SESSION_TTL}; Path=/; HttpOnly; SameSite=Lax")],
        )

    def do_PUT(self):
        parsed = urlparse(self.path)
        if parsed.path != "/api/vault":
            return self.send_error(HTTPStatus.NOT_FOUND)
        email, _token = user_for_request(self)
        if not email: return self.json_response({"error":"unauthorized"}, HTTPStatus.UNAUTHORIZED)
        try: body = self.read_json(); vault = sanitize_vault_blob(body)
        except Exception as exc: return self.json_response({"error": str(exc)}, HTTPStatus.BAD_REQUEST)
        user = load_users()["users"].get(email)
        if not user: return self.json_response({"error":"unauthorized"}, HTTPStatus.UNAUTHORIZED)
        path = VAULT_DIR / user["vaultFile"]
        tmp = path.with_suffix(".nbv.tmp")
        with LOCK:
            tmp.write_text(json.dumps(vault, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, path)
            try: os.chmod(path, 0o600)
            except OSError: pass
        return self.json_response({"ok": True})


if __name__ == "__main__":
    print("NorthByte Vault file edition")
    print("Storage: data/users.json + data/vaults/*.nbv")
    print("Open: http://127.0.0.1:8080")
    ThreadingHTTPServer(("127.0.0.1", 8080), Handler).serve_forever()
