# NorthByte Vault — File Edition

**NorthByte Norway Tec .Ltd.**

Local-first password vault with **no SQLite**. Persistent data is stored as files:

```text
data/
├── users.json
└── vaults/
    ├── <user-id>.nbv
    └── ...
```

## How it works

- `users.json` stores account metadata, an authentication salt, and a hardened verifier hash.
- Each user's `.nbv` file contains only an encrypted vault payload.
- The browser derives the encryption key from the master password using PBKDF2-HMAC-SHA-256 with 600,000 iterations.
- Vault contents are encrypted with AES-256-GCM before being written to the `.nbv` file.
- The server never receives the master password itself. During login the browser sends a derived verifier, which the local server hardens with scrypt before comparison.
- Sign out only destroys the current in-memory session cookie. `users.json` and the `.nbv` file remain.
- Bitwarden JSON can be imported locally.
- The current encrypted `.nbv` can be downloaded as a backup.

## Run

Python 3.10+ recommended. No Python package installation is required.

```bash
python server.py
```

Open:

`http://127.0.0.1:8080`

Do **not** double-click `index.html`; use the included local server.

## Bitwarden

Use Bitwarden's standard JSON export. Login, secure note, card, and identity records are imported into the NorthByte Vault model. The imported records are then encrypted in the browser before being saved to the user's `.nbv` file.

## Security scope

This is a local community edition, not an independently audited password manager. The cryptographic design is intended to provide meaningful at-rest protection, but a production security review is still required before using it as a high-assurance credential store.

Do not export a vault to plain CSV/TXT unless you explicitly accept that the exported file will contain plaintext secrets. The `.nbv` backup remains encrypted.

## Backup

Back up the whole `data/` directory. A user can also use **Backup .nbv** from the UI to save their encrypted vault file.


## Important: do not use Python's static http.server

Do **not** start this project with `python -m http.server 8080`. That command only serves static files and cannot provide the `/api/register`, `/api/login`, `/api/vault`, or `/api/logout` endpoints used by NorthByte Vault.

Use:

```bash
python server.py
```

Then open `http://127.0.0.1:8080`.


## Windows run note

Do not start this project with `python -m http.server 8080`; that command only serves static files and cannot provide the `/api/*` endpoints. Use `python server.py` or double-click `start.bat`.
